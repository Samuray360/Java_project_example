


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.util.Random;


public class Dice_controller {
    Random random = new Random();

    Integer roll = 0;
    String roll_String = ""; 

    @FXML
    Label Dice_face;

    @FXML
    ImageView dice_img;


    @FXML
    void Onbuttonclick(ActionEvent event) {
        int number = random.nextInt(6);
        
        switch(number){
            case 0 : 
                roll = 1 ;
                roll_String = roll.toString();
                Dice_face.setText(roll_String);
                dice_img.setImage(new Image("cara1.png"));
                break;
            case 1 : 
                roll = 2 ;
                roll_String = roll.toString();
                Dice_face.setText(roll_String);
                dice_img.setImage(new Image("cara2.png"));
                break;
            case 2 : 
                roll = 3 ;
                roll_String = roll.toString();
                Dice_face.setText(roll_String);
                dice_img.setImage(new Image("cara3.png"));
                break;
            case 3 : 
                roll = 4 ;
                roll_String = roll.toString();
                Dice_face.setText(roll_String);
                dice_img.setImage(new Image("cara4.png"));
                break;
            case 4 : 
                roll = 5 ;
                roll_String = roll.toString();
                Dice_face.setText(roll_String);
                dice_img.setImage(new Image("cara5.png"));
                break;
            case 5 : 
                roll = 6 ;
                roll_String = roll.toString();
                Dice_face.setText(roll_String);
                dice_img.setImage(new Image("cara6.png"));
                break;
            
        }
        
      

    }
      
       

}