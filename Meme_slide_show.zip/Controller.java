import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;


public class Controller {

    int image = 0;

    boolean img_change = false; 

    @FXML
    ImageView img;



    @FXML
    public void next_img (){
        
        image++;
       
        switch (image) {
            case 1:
                img.setImage(new Image("Meme2.jpg"));
                break;
            case 2:
                img.setImage(new Image("Meme3.jpg"));
                break;
            case 3:
                img.setImage(new Image("Meme4.jpg"));
                break;
            case 4:
                img.setImage(new Image("Meme5.jpeg"));
                break;
            case 5:
                img.setImage(new Image("Meme1.jpg"));
                image = 1;
                break;

        
        }


          
     
        }
    
    @FXML
    void OnButtonClick(ActionEvent event) {
       
        next_img();
           
          
    }   
    
   
}

